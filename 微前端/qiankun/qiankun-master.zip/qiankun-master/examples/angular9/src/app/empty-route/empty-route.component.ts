import { Component } from '@angular/core';

@Component({
  selector: 'angular9-empty-route',
  template: '',
})
export class EmptyRouteComponent {}
