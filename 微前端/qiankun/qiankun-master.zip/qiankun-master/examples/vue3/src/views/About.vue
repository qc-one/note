<template>
  <div class="about-content">
    <h1>This is about page</h1>
  </div>
</template>

<script>
export default {
  name: 'About',
  setup() {},
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.about-content {
  color: #7265e6;
}
</style>
