import { createStore } from 'vuex';
import count from './count';

export default createStore({
  state: {},
  mutations: {},
  actions: {},
  getters: {},
  modules: {
    count,
  },
});
