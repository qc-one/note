<template>
    <div>app</div>
</template>

<script>
export default {
    name: "App",
};
</script>

<style>
</style>
