<template>
    <div>
        <h1>我是PageTwo组件</h1>
    </div>
</template>
<script>
export default {
    name: "PageTwo",
    data() {
        return {};
    },
};
</script>