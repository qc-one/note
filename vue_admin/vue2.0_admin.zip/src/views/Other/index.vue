<template>
    <div>
        <h1>我是Other组件</h1>
        <router-view></router-view>
    </div>
</template>
<script>
export default {
    name: "Other",
    data() {
        return {};
    },
};
</script>