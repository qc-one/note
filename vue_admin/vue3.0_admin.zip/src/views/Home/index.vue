<script>
import { ref, defineComponent } from "vue";

export default defineComponent({
    components: {},
    setup() {},
});
</script>

<template>
    <div>我是home组件</div>
</template>

<style scoped>
.read-the-docs {
    color: #888;
}
</style>
