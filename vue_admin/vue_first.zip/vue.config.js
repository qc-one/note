// const path = require("path");
// import path from 'path'

module.exports = defineConfig({
    transpileDependencies: true,
})